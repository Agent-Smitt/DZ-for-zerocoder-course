const menuButton = document.querySelector('.menu-toggle');
const mobileMenu = document.querySelector('.mobile-menu');

function closeMenu() {
  menuButton.setAttribute('aria-expanded', 'false');
  menuButton.setAttribute('aria-label', 'Открыть меню');
  mobileMenu.hidden = true;
}

menuButton.addEventListener('click', () => {
  const isOpen = menuButton.getAttribute('aria-expanded') === 'true';
  menuButton.setAttribute('aria-expanded', String(!isOpen));
  menuButton.setAttribute('aria-label', isOpen ? 'Открыть меню' : 'Закрыть меню');
  mobileMenu.hidden = isOpen;
});

mobileMenu.querySelectorAll('a').forEach(link => link.addEventListener('click', closeMenu));
document.addEventListener('keydown', event => {
  if (event.key === 'Escape') closeMenu();
});

const modules = document.querySelectorAll('.module');
modules.forEach(module => {
  module.addEventListener('toggle', () => {
    if (module.open) modules.forEach(other => { if (other !== module) other.open = false; });
  });
});

const form = document.querySelector('#enroll-form');
const message = document.querySelector('#form-message');
const nameInput = document.querySelector('#name');
const contactInput = document.querySelector('#contact');

form.addEventListener('submit', event => {
  event.preventDefault();
  const name = nameInput.value.trim();
  const contact = contactInput.value.trim();
  const validContact = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contact) || /^\+?[\d\s()+-]{10,}$/.test(contact);

  nameInput.classList.toggle('invalid', name.length < 2);
  contactInput.classList.toggle('invalid', !validContact);

  if (name.length < 2 || !validContact) {
    message.textContent = 'Пожалуйста, укажите имя и корректный email или номер телефона.';
    message.className = 'form-message error';
    (name.length < 2 ? nameInput : contactInput).focus();
    return;
  }

  message.textContent = `Спасибо, ${name}! Это демонстрационная форма, поэтому заявка не была отправлена.`;
  message.className = 'form-message success';
  form.reset();
  nameInput.classList.remove('invalid');
  contactInput.classList.remove('invalid');
});

[nameInput, contactInput].forEach(input => input.addEventListener('input', () => {
  input.classList.remove('invalid');
  if (message.classList.contains('error')) message.textContent = '';
}));
