from flask import Flask, render_template, jsonify
import json

app = Flask(__name__)

# Загружаем карточки из JSON-файла
with open('content.json', 'r', encoding='utf-8') as f:
    cards = json.load(f)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/cards')
def get_cards():
    return jsonify(cards)

if __name__ == '__main__':
    app.run(debug=True)
