// Загружаем карточки с сервера
fetch('/api/cards')
    .then(response => response.json())
    .then(cards => {
        renderCards(cards);
        setupSearch(cards);
    })
    .catch(error => {
        console.error('Ошибка загрузки карточек:', error);
    });

// Функция отрисовки карточек
function renderCards(cards) {
    const container = document.getElementById('cardsContainer');
    const noResults = document.getElementById('noResults');

    if (cards.length === 0) {
        container.innerHTML = '';
        noResults.style.display = 'block';
        return;
    }

    noResults.style.display = 'none';
    container.innerHTML = cards.map(card => `
        <div class="card">
            <h3>${card.title}</h3>
            <p>${card.description}</p>
            <div class="tags">
                ${card.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
            </div>
            <a href="${card.link}" class="btn" target="_blank" rel="noopener">Открыть материал</a>
        </div>
    `).join('');
}

// Функция поиска
function setupSearch(allCards) {
    const searchInput = document.getElementById('searchInput');

    searchInput.addEventListener('input', function() {
        const query = this.value.toLowerCase().trim();

        const filtered = allCards.filter(card => {
            const title = card.title.toLowerCase();
            const description = card.description.toLowerCase();
            const tags = card.tags.join(' ').toLowerCase();

            return title.includes(query) || description.includes(query) || tags.includes(query);
        });

        renderCards(filtered);
    });
}
